/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_3;

import Database.DataBase;
import Database.Table;
import Models.Movie;

/**
 *
 * @author andrew
 */
public class Lab_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        DataBase db = new DataBase("andrew", "andrew", "lab3", "3306");
        
        Table<Movie> movies = new Table<>(db.getConnection(), "Movie", new Movie());
        
        Movie m = new Movie();
        m.setmID(109);
        m.setTitle("Lol");
        m.setYear(2010);
        m.setDirector("Andrew");
        movies.Create(m);
        
        
        
        
        System.out.print("END.\n\r");
    }
    
}
