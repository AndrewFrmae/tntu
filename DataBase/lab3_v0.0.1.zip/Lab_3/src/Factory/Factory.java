/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factory;

import java.sql.Connection;
import java.sql.ResultSet;

/**
 *
 * @author andrew
 * @param <T>
 */
public interface Factory<T> {
    T create(ResultSet res);
    T insertRow(Connection connection);
    T updateRow(Connection connection, int... params);
    boolean deleteRow(Connection connection, int... params);
}
