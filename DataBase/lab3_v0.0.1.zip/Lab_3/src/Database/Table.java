/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import Factory.Factory;

/**
 *
 * @author andrew
 * @param <T>
 */
public class Table<T extends Factory<T>> {
    private final String tableName;
    private final Connection connection;
    private final Factory<T> factory;
    
    /**
     * 
     * @param conn
     * @param name 
     * @param elem 
     */
    
    public Table(Connection conn, String name, Factory<T> elem) {
        this.connection = conn;
        this.tableName = name;
        this.factory = elem;
    }
    
    public ArrayList<T> GetAll() {
        try (Statement stm = connection.createStatement(
                        ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_READ_ONLY)) {
            ArrayList<T> list = new ArrayList<>();
            ResultSet res = stm.executeQuery("SELECT * FROM " + this.tableName);
            
            while (res.next()) {
                T row = factory.create(res);
                if(row != null)
                    list.add(row);
            }
            stm.close();
            return list;
        } catch (SQLException ex) {
            return null;
        }
        
    }
    
    public T Create (T item) {
        return item.insertRow(connection);
    }
    
    public T Update (T item, int... ids) {
        return item.updateRow(connection, ids);
    }
    
    public boolean Delete (int... ids) {
        return factory.deleteRow(connection, ids);
    }
    
}
