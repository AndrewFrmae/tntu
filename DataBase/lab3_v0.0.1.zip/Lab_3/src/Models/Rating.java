/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import Factory.Factory;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author andrew
 */
public class Rating implements Factory<Rating> {
    private int rID;
    private int mID;
    private int stars;
    private Date ratingDate;
    
    @Override
    public Rating create(ResultSet res) {
        try {
            Rating r = new Rating();
            r.rID = res.getInt("rID");
            r.mID = res.getInt("mID");
            r.stars = res.getInt("stars");
            r.ratingDate = res.getDate("ratingDate");
            return r;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Rating insertRow(Connection connection) {
        String sql = "INSERT INTO Movie (rID, mID, stars, ratingDate)"
                + " VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.rID);
            statement.setInt(2, this.mID);
            statement.setInt(3, this.stars);
            statement.setDate(4, this.ratingDate);
            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Rating updateRow(Connection connection, int... params) {
        if(params.length != 2)
            return null;
        
        String sql = "UPDATE Users SET rID=?, mID=?, stars=?, ratingDate=? "
                + "WHERE rID=? and mID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.rID);
            statement.setInt(2, this.mID);
            statement.setInt(3, this.stars);
            statement.setDate(4, this.ratingDate);
            statement.setInt(5, params[0]);   
            statement.setInt(6, params[1]);

            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public boolean deleteRow(Connection connection, int... params) {
        if(params.length != 2)
            return false;
        
        String sql = "DELETE FROM Movie WHERE rID=? and mID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, params[0]);
            statement.setInt(2, params[1]);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
    
    public int getrID() {
        return rID;
    }

    public void setrID(int rID) {
        this.rID = rID;
    }

    public int getmID() {
        return mID;
    }

    public void setmID(int mID) {
        this.mID = mID;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public Date getRatingDate() {
        return ratingDate;
    }

    public void setRatingDate(Date ratingDate) {
        this.ratingDate = ratingDate;
    }
}
