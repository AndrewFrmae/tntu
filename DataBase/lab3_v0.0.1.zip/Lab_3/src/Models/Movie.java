/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import Factory.Factory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author andrew
 */
public class Movie implements Factory<Movie> {
    private int mID;
    private String title;
    private int year;
    private String director;

    @Override
    public Movie create(ResultSet res) {
        try {
            Movie m = new Movie();
            m.mID = res.getInt("mID");
            m.title = res.getString("title");
            m.year = res.getInt("year");
            m.director = res.getString("director");
            return m;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Movie insertRow(Connection connection) {
        String sql = "INSERT INTO Movie (mID, title, year, director)"
                + " VALUES (?, ?, ?, ?)";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.mID);
            statement.setString(2, this.title);
            statement.setInt(3, this.year);
            statement.setString(4, this.director);
            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Movie updateRow(Connection connection, int... params) {
        String sql = "UPDATE Users SET mID=?, title=?, year=?, director=? "
                + "WHERE mID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.mID);
            statement.setString(2, this.title);
            statement.setInt(3, this.year);
            statement.setString(4, this.director);
            statement.setInt(5, params[0]);
            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }

    @Override
    public boolean deleteRow(Connection connection, int... params) {
        String sql = "DELETE FROM Movie WHERE mID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, params[0]) ;

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            return false;
        }
    }
    
    public int getmID() {
        return mID;
    }

    public void setmID(int mID) {
        this.mID = mID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
}
