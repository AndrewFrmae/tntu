/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.ResultSet;
import java.sql.SQLException;
import Factory.Factory;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author andrew
 */
public class Reviewer implements Factory<Reviewer> {
    private int rID;
    private String name;

    @Override
    public Reviewer create(ResultSet res) {
        try {
            Reviewer r = new Reviewer();
            r.rID = res.getInt("rID");
            r.name = res.getString("name");
            return r;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Reviewer insertRow(Connection connection) {
        String sql = "INSERT INTO Movie (rID, name)"
                + " VALUES (?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.rID);
            statement.setString(2, this.name);
            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public Reviewer updateRow(Connection connection, int... params) {
        String sql = "UPDATE Users SET rID=?, name=? "
                + "WHERE rID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, this.rID);
            statement.setString(2, this.name);
            statement.setInt(3, params[0]);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                return this;
            }
            return null;
        } catch (SQLException ex) {
            return null;
        }
    }
    
    @Override
    public boolean deleteRow(Connection connection, int... params) {
        String sql = "DELETE FROM Movie WHERE rID=?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, params[0]);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public int getrID() {
        return rID;
    }

    public void setrID(int rID) {
        this.rID = rID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }    
}
